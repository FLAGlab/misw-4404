
public interface TennisGame {
    void wonPoint(String playerName);
    String getScore();
}