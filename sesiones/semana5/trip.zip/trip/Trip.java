package org.craftedsw.tripservicekata.trip;

public class Trip {

}
